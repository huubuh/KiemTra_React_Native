 import { Text, View, StyleSheet,Image,TextInput,TouchableOpacity} from 'react-native';
 import useState from "react"
const Caculator = () =>{


  return (<>
      <View style={styles.constructor}> 

      <View style={{flex:0.2 ,justifyContent:"center",alignItems:"center"}}>
      <Text style={{fontSize:18,fontWeight:"bold",backgroundColor:"lightblue"}}> Caculator </Text>
      </View>
        <View style={styles.input}><TextInput 
        placeholder="Nhập số"/>
            
        </View>
        <View style={styles.paragrap}> <Text >Kết quả :</Text></View>
        
        <View>
        <View style={{flexDirection:"row",gap:2}}>
        <TouchableOpacity style ={styles.button}>
         <Text>+</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>-</Text>
         </TouchableOpacity >
         <TouchableOpacity style ={styles.button}>
         <Text>x</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>:</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>C</Text>
         </TouchableOpacity>
         </View>
         <View style={{flexDirection:"row",gap:2}}>
         <TouchableOpacity style ={styles.button}>
         <Text>0</Text>
         </TouchableOpacity>
       <TouchableOpacity style ={styles.button}>
         <Text>1</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>2</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>3</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>4</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>5</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>6</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>7</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>8</Text>
         </TouchableOpacity>
         <TouchableOpacity style ={styles.button}>
         <Text>9</Text>
         </TouchableOpacity >
         </View>
        </View>
        
      </View>
  </>
  )
}
export default Caculator;
const styles = StyleSheet.create({
    constructor : {
      flex:1,
      backgroundColor:"white"
    },
    button :{
      width : 30,
      height : 30,
      borderWidth:1,
      borderRadius: 5,
      backgroundColor:"lightgray",
      justifyContent:"center",
      alignItems: "center"
    },
    input:{
        borderRadius:5,
        borderWidth:1,
        height:30,
        justifyContent:"center",
        margin : 2,
    padding : 10
    
    }
    ,
    paragrap:{
      borderWidth : 1,
      borderRadius:5,
      height:30,
      justifyContent: "center",
      padding:10
    },




});